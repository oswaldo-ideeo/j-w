
<div class="login-dismis"></div>
<div class="row" id="login">
	<div class="col-sm-12 col-md-12">
		<div class="color-white">
			<div class="row">	
				<div class="row paddin-reg">
					<div class="col-md-12">
						<p><b>USUARIO</b></p>
					</div>
					<div class="col-md-12">
						<input class="circle-border2" type="text" name="adjunta" placeholder="Nombre de usuario">
					</div>
				</div>

				<div class="row paddin-reg paddin-inp">
					<div class="col-md-12">
						<p><b>CONTRASEÑA</b></p>
					</div>
					<div class="col-md-12">
						<input class="circle-border2" type="text" name="adjunta" placeholder="Contraseña">
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 olv-cont">
						<a href="#"><p class="condiciones"><b class="term">Olvide mi contraseña</b></p></a>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12 paddin-buttonenv">
						<a class="registro" href="home.php">INICIAR SESIÓN</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
